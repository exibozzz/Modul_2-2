<?php

$naslov = "Postani Programer";

$ime = "Ognjen";
$prezime = "Topic";
$godiste = "1998";
$trenutna_godina = date("Y");
$godine = $trenutna_godina-$godiste;


$folder = ["Glavna", "Kontakt", "O nama"];



?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?=$naslov;?></title>
</head>
<body>

<ul>

<li><?=$folder[0]?></li>
<li><?=$folder[1]?></li>
<li><?=$folder[2]?></li>

</ul>

<ul>

<li><?=$ime;?></li>
<li><?=$prezime;?></li>
<li><?=$godiste;?></li>
<li><?=$godine?></li>

</ul>


    
</body>
</html>